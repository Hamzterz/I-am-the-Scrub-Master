from django.apps import AppConfig


class BusinessmanConfig(AppConfig):
    name = 'businessman'
